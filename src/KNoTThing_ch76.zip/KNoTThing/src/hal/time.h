/*
 * Copyright (c) 2016, CESAR.
 * All rights reserved.
 *
 * This software may be modified and distributed under the terms
 * of the BSD license. See the LICENSE file for details.
 *
 */

#ifndef __HAL_TIME_H__
#define __HAL_TIME_H__

#ifdef __cplusplus
extern "C" {
#endif

uint32_t hal_time_ms(void);
uint32_t hal_time_us(void);
void hal_delay_ms(uint32_t ms);
void hal_delay_us(uint32_t us);
int hal_timeout(uint32_t current,  uint32_t start,  uint32_t timeout);
int hal_getrandom(void *buf, size_t buflen);

#ifdef __cplusplus
}
#endif

#endif /* __HAL_TIME_H__ */
